package com.example.demo.controller;

import com.example.demo.services.RequestData;
import org.springframework.web.bind.annotation.*;

@RestController
public class NomController {

    @PostMapping("/monservice/hello")
    public String hello(@RequestBody RequestData requestData) {
        return "Hello, " + requestData.getNom() + "!";
    }

    @GetMapping("/monservice/echo/{nom}")
    public String echo(@PathVariable String nom) {
        return "Bonjour, " + nom + "!";
    }
}
