package com.example.demo.services;

public class RequestData {
    String nom;

    public RequestData(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
}
